<?php
require_once("db.form.php");
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>L&B Furniture</title>
    <link rel="stylesheet" href="style.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins&display=swap"
      rel="stylesheet"
    />
  </head>
  <body onload="slider()">
    <div class="back">
      <div class="slider">
        <img src="images/bedroom.jpeg" alt="" id="slideImg" />
      </div>
      <div class="overlay">
        <div class="nav-design">
          <div class="logo">L&B FURNITURE</div>
        </div>
        <div class="content">
          <h1>L&B is all you need!</h1>
          <h3>
            All customers are required to create an account before they are able
            to continue to the homepage
          </h3>
          <h3>Do you have an account already? Please login in below:</h3>
          <div>
            <form action="login.form.php" method="POST">
              <label class="usernamestyle">User Name :</label
              ><input
                class="loginbox"
                style="margin-bottom: 100px"
                type="text"
                name="usersUSERSNAME"
                placeholder="Enter User Name"
              /><br />
              <label class="passwordusername">Password: </label
              ><input
                class="passwordbox"
                type="password"
                name="usersPWD"
                placeholder="Enter Password"
              />
              <button class="loginbuttons" type="submit">Login</button>
            </form>
            <form action="register.form.php" method="POST">
              <button class="registerbutton" type="Submit">
                Create an account
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
    <script>
      var slideImg = document.getElementById("slideImg");

      var images = new Array(
        "images/bedroom.jpg",
        "images/office.jpg",
        "images/livingroom.jpg",
        "images/diningroom.jpg",
        "images/bathroom.jpg"
      );

      var len = images.length;
      var i = 0;

      function slider() {
        if (i > len - 1) {
          i = 0;
        }
        slideImg.src = images[i];
        i++;
        setTimeout("slider()", 4000);
      }
    </script>
  </body>
</html>
