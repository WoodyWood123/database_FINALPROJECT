<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>L&B Furniture</title>
    <link rel="stylesheet" href="styles.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins&display=swap"
      rel="stylesheet"
    />
    <script src="https://use.fontawesome.com/56da674dd1.js"></script>

</head>
<body>
<header class="headerhomepage">
<a href="#" class="homelogo">
    <img src="images/logo.png" alt="">
</a>
<nav class="homenav">
    <a href ="#Home">Home</a>
    <a href="#About Us">About Us</a>
    <a href="#Products">Products</a>
    <a href="#Contact Info">Contact Info</a>
</nav>
<div class="icons">
  <div class="fa fa-search"></div>
  <div class="fa fa-shopping-cart"></div>
  <div class="bars" id="menu-btn"></div>
</div>
</header>





</body>
</html>