<?php

session_start();

include("db.form.php");
include("functions.php");


if($_SERVER['REQUEST_METHOD'] == "POST"){
  $usersFName = $_POST['Fname'];
  $usersLName = $_POST['Lname'];
  $usersUSERSNAME = $_POST['usersUSERSNAME'];
  $usersEMAIL = $_POST['Email'];
  $usersPNUM = $_POST['Pnum'];
  $usersBDATE = $_POST['Bdate'];
  $usersPWD = $_POST['usersPWD'];
  $Passrepeat = $_POST['Passrepeat'];


  if (!empty($usersUSERSNAME) && !empty($usersPWD) && !is_numeric($usersUSERNAME)){
   
    $query = "insert into users (usersFName, usersLName, usersEMAIL, usersUSERSNAME,usersPNUM, usersBDATE, usersPWD) 
    values ('$usersFName', '$usersLName', '$usersEMAIL', '$usersUSERSNAME','$usersPNUM', '$usersBDATE', '$usersPWD')";
    mysqli_query($conn, $query);

    header("Location: loginpage.php");
    die;
  }
}


  





 



