<?php


$servername = "localhost";
$dbUsername = "woodrub1_user2";
$dbPass = "database12345";
$dbName = "woodrub1_ecommerce";

$conn = mysqli_connect($servername, $dbUsername, $dbPass, $dbName);

