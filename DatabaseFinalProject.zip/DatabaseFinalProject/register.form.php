<?php

session_start();

include("db.form.php");
include("functions.php");

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="style.css" />
    <title>Registration Form</title>
  </head>
  <body class="registerbody">
    <img class="logoregister" src="images/logo.png" />
    <div class="registerformcontainer">
      <div class="titlestyle">Registration Form</div>
      <form action="signup.form.php" method="POST">
        <div class="inputform">
          <div class="userinputboxes">
            <span class="userdetails">First Name:</span>
            <input name="Fname" type="text" placeholder="Enter your First Name " required />
          </div>
          <div class="userinputboxes">
            <span class="userdetails">Last Name:</span>
            <input name="Lname" type="text" placeholder="Enter your Last Name " required />
          </div>
          <div class="userinputboxes">
            <span class="userdetails">Enter User Name:</span>
            <input name="usersUSERSNAME" type="text" placeholder="Enter your desired User name " required />
          </div>
          <div class="userinputboxes">
            <span class="userdetails">Email:</span>
            <input name="Email"
              value=""
              onchange="try{setCustomValidity('')}catch(e){}"
              type="email"
              placeholder="Enter your Email address "
              id="email"
              name="email"
              pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$"
              required
            />
          </div>
          <div class="userinputboxes">
            <span class="userdetails">Phone Number:</span>
            <input name="Pnum"
              type="text"
              placeholder="Enter your Phone Number "
              required
            />
          </div>
          <div class="userinputboxes">
            <span class="userdetails">Date of Birth:</span>
            <input name="Bdate" type="date" required />
          </div>
          <div class="userinputboxes">
            <span class="userdetails">Password:</span>
            <input
            name="usersPWD"
              type="password"
              placeholder="Enter your Password "
              required
            />
          </div>
          <div class="userinputboxes">
            <span class="userdetails">Confirm Password:</span>
            <input
            name="Passrepeat"
              type="password"
              placeholder="Confirm your Password"
              required
            />
          </div>
        </div>
        <div class="button">
          <input type="submit" value="Create account" />
        </div>
      </form>
    </div>
</html>
